package com.example.todoApplication;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class TodoController implements Initializable {

    @FXML
    private Label user_name;

    @FXML
    private TextField taskInput;

//    @FXML
//    private TextField idInput;

    @FXML
    private TextField descriptionInput;

    @FXML
    private TextField dueDateInput;

    @FXML
    private TableView<Task> tableView;

    @FXML
    private TableColumn<Task, Integer> id;

    @FXML
    private TableColumn<Task, String> taskName;

    @FXML
    private TableColumn<Task, String> description;

    @FXML
    private TableColumn<Task, String> dueDate;

    ObservableList<Task> taskList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        taskName.setCellValueFactory(new PropertyValueFactory<>("taskName"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        dueDate.setCellValueFactory(new PropertyValueFactory<>("dueDate"));

        tableView.setItems(taskList);
        populateTable();
    }

    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }

    private void populateTable() {
        taskList.clear();

        String jdbcUrl = "jdbc:mysql://localhost:3306/todo";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM `todo`";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String taskName = resultSet.getString("task_name");
                String description = resultSet.getString("description");
                String dueDate = resultSet.getString("due_date");
                taskList.add(new Task(id, taskName, description, dueDate));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertTask(ActionEvent actionEvent) {
        String taskName = taskInput.getText();
        String description = descriptionInput.getText();
        String dueDate = dueDateInput.getText();

        insertTaskToDatabase(taskName, description, dueDate);
        populateTable();
    }

    public void deleteTask(ActionEvent actionEvent) {
        Task selectedTask = tableView.getSelectionModel().getSelectedItem();
        if (selectedTask != null) {
            deleteTaskFromDatabase(selectedTask.getId());
            populateTable();
        }
    }

    public void updateTask(ActionEvent actionEvent) {
        Task selectedTask = tableView.getSelectionModel().getSelectedItem();
        if (selectedTask != null) {
            String updatedTaskName = taskInput.getText();
            String updatedDescription = descriptionInput.getText();
            String updatedDueDate = dueDateInput.getText();

            updateTaskInDatabase(selectedTask.getId(), updatedTaskName, updatedDescription, updatedDueDate);
            populateTable();
        }
    }

    public void loadTasks(ActionEvent actionEvent) {
        populateTable();
    }

    public void set_username(String message) {
        user_name.setText(message);
    }

    private void insertTaskToDatabase(String taskName, String description, String dueDate) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/todo";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO `todo` (`task_name`, `description`, `due_date`) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, taskName);
            preparedStatement.setString(2, description);
            preparedStatement.setString(3, dueDate);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteTaskFromDatabase(int taskId) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/todo";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM `todo` WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, taskId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateTaskInDatabase(int taskId, String updatedTaskName, String updatedDescription, String updatedDueDate) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/todo";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE `todo` SET `task_name` = ?, `description` = ?, `due_date` = ? WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, updatedTaskName);
            preparedStatement.setString(2, updatedDescription);
            preparedStatement.setString(3, updatedDueDate);
            preparedStatement.setInt(4, taskId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
