module com.example.todoApplication {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.todoApplication to javafx.fxml;
    exports com.example.todoApplication;
}